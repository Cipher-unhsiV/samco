# Gap Detection > 2025-01-07 11:03am
https://universe.roboflow.com/starter-3re5h/gap-detection-os0yg

Provided by a Roboflow user
License: CC BY 4.0

