# gap-pattern > 2024-02-26 7:57pm
https://universe.roboflow.com/workathon/gap-pattern

Provided by a Roboflow user
License: CC BY 4.0

