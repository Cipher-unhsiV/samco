from phi.agent import Agent, RunResponse
#from phi.model.groq import Groq
from phi.model.huggingface import HuggingFaceChat
from phi.tools.yfinance import YFinanceTools
from phi.tools.duckduckgo import DuckDuckGo
import openai
"""
import os
from dotenv import load_dotenv
load_dotenv()
openai.api_key=os.getenv("OPENAI_API_KEY")
"""
## web search agent
web_search_agent=Agent(
    name="Web Search Agent",
    role="Search the web for the information",
    model=HuggingFaceChat(
        id="meta-llama/Llama-3.2-3B-Instruct",
        max_tokens=3096,
    ),
    tools=[DuckDuckGo()],
    instructions=["Alway include sources"],
    show_tools_calls=True,
    markdown=True,

)

## Financial agent
finance_agent=Agent(
    name="Finance AI Agent",
    model=HuggingFaceChat(
        id="meta-llama/Llama-3.2-3B-Instruct",
        max_tokens=3096,
    ),
    tools=[
        YFinanceTools(stock_price=True, analyst_recommendations=True, stock_fundamentals=True,
                      company_news=True),
    ],
    instructions=["Use tables to display the data whenever required"],
    show_tool_calls=True,
    markdown=True,

)

multi_ai_agent=Agent(
    team=[web_search_agent,finance_agent],
    model=HuggingFaceChat(
        id="meta-llama/Llama-3.2-3B-Instruct",
        max_tokens=3096,
        api_key = "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",
    ),
    instructions=["Always include sources", "Use tables to display data whenever required"],
    show_tool_calls=True,
    markdown=True,
)
#multi_ai_agent.print_response("Summarize analyst recommendations and share the latest news for NVDA")

run: RunResponse = multi_ai_agent.run("Share a 2 sentence horror story.")
print(run.content)