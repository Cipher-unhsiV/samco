from phi.agent import Agent, RunResponse
from phi.model.groq import Groq
from phi.storage.agent.postgres import PgAgentStorage
from phi.knowledge.pdf import PDFUrlKnowledgeBase
from phi.vectordb.pgvector import PgVector, SearchType
from phi.embedder.google import GeminiEmbedder
import httpx
import os
from dotenv import load_dotenv
import gardio as gr

load_dotenv()
os.environ["GROQ_API_KEY"]=os.getenv("GROQ_API_KEY")
print(os.getenv("GROQ_API_KEY"))
client = httpx.Client(timeout=httpx.Timeout(60.0))
db_url = "postgresql+psycopg://ai:ai@localhost:5532/ai?connect_timeout=60"
knowledge_base=PDFUrlKnowledgeBase(
    urls=["https://www.joghat.org/uploads/2024-vol-7-issue-1-full-text-405.pdf"],
    vector_db=PgVector(
        table_name="recipies1",
        db_url=db_url, 
        embedder=GeminiEmbedder(dimensions=768),
        search_type=SearchType.hybrid,
        )
)
knowledge_base.load(recreate=True, upsert=True)
storage=PgAgentStorage(table_name="pdf-assistant1",db_url=db_url)
agent = Agent(
    model=Groq(id="llama-3.3-70b-versatile"),
    knowledge=knowledge_base,
    storage=storage,
    #read_chat_history=True,
    #show_tool_calls=True,
    #markdown=True,
    #debug_mode=True,
)
ans = agent.print_response("Summarize the document within 5000 tokens!", stream=True)
print(ans)

#response: RunResponse = agent.run("What is The 'Michelin Guide'. Explain in 3 sentences.")
#res = response.content
