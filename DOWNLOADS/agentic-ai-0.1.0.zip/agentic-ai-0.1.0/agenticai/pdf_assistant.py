from phi.agent import Agent, RunResponse
from phi.model.groq import Groq
from phi.storage.agent.postgres import PgAgentStorage
from phi.knowledge.pdf import PDFUrlKnowledgeBase
from phi.vectordb.pgvector import PgVector, SearchType
from phi.embedder.google import GeminiEmbedder
import httpx


import os
from dotenv import load_dotenv
load_dotenv()
os.environ["GROQ_API_KEY"]=os.getenv("GROQ_API_KEY")

client = httpx.Client(timeout=httpx.Timeout(None))

db_url = "postgresql+psycopg://ai:ai@localhost:5532/ai?connect_timeout=60"

#groq_embedder = TogetherEmbedder()

knowledge_base=PDFUrlKnowledgeBase(
    urls=["https://www.joghat.org/uploads/2024-vol-7-issue-1-full-text-405.pdf"],
    vector_db=PgVector(
        table_name="recipies",
        db_url=db_url, 
        embedder=GeminiEmbedder(dimensions=768),
        search_type=SearchType.hybrid,
        )
)
knowledge_base.load(recreate=True, upsert=True)
#knowledge_base.load()

storage=PgAgentStorage(table_name="pdf-assistant",db_url=db_url)
"""
def pdf_assistant(new: bool = False, user: str = "user"):
    run_id: Optional[str] = None

    if not new:
        existing_run_ids: List[str] = storage.get_all_run_ids(user)
        if len(existing_run_ids) > 0:
            run_id = existing_run_ids[0]

    assistant = Assistant(
        run_id=run_id,
        user_id=user,
        knowledge_base=knowledge_base,
        storage=storage,
        show_tool_calls=True,
        search_knowledge=True,
        read_chat_history=True,
    )
    if run_id is None:
        run_id = assistant.run_id
        print(f"Started Run: {run_id}\n")
    else:
        print(f"Continuing Run: {run_id}\n")

    assistant.cli_app(markdown=True)

if __name__=="__main__":
    typer.run(pdf_assistant)

"""

agent = Agent(
    model=Groq(id="llama-3.3-70b-versatile"),
    #model = SentenceTransformer('all-mpnet-base-v2', truncate_dim=384),
    knowledge=knowledge_base,
    storage=storage,
    #read_chat_history=True,
    #show_tool_calls=True,
    #markdown=True,
    #debug_mode=True,
)

ans = agent.print_response("What is The 'Michelin Guide'. Explain in 3 sentences.", stream=True)
#agent.print_response("What was my last question?", stream=True)
print(ans)

#response: RunResponse = agent.run("What is The 'Michelin Guide'. Explain in 3 sentences.")
#res = response.content


