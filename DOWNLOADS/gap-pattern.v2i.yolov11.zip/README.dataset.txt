# gap-pattern > 2025-01-07 5:38pm
https://universe.roboflow.com/starter-3re5h/gap-pattern-kjvnx

Provided by a Roboflow user
License: CC BY 4.0

