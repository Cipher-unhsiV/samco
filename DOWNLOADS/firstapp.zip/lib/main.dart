import 'dart:ui';

import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
          body: Center(
              child: Text(
        "This is my very first FLUTTER APP!!!",
        style: TextStyle(
            fontSize: 60,
            backgroundColor: Colors.lightBlueAccent,
            fontWeight: FontWeight.w900,
            fontStyle: FontStyle.italic),
        textAlign: TextAlign.center,
      ))),
    );
  }
}
