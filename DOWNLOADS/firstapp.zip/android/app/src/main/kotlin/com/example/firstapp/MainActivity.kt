package com.example.firstapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
